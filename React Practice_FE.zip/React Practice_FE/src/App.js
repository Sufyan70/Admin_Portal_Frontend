import logo from './logo.svg';
import './App.css';
import Routing from './Routes/routing';

function App() {
  return (
    <>
      <Routing />
    </>
  );
}

export default App;
