import React from "react";
import Header from "../components/Includes/Header";
import CountriesList from "./components/CountriesList";

const HR_CountriesList = () => {
  return (
    <>
      <div>
        <Header />
      </div>
      <div className="mt-5">
        <CountriesList />
      </div>
    </>
  );
};

export default HR_CountriesList;
