import React from "react";
import "../assets/css/CountriesList.css";

function CountriesList() {
  return (
    <div className="container-fluid p-2">
      <div className="container-fluid mt-2  CountriesListContainer">
        <span className="CountriesListHeader py-2">Countries List</span>
        <div className="row px-3 mt-2 py-1">
          <div className="col-lg-5 d-flex"></div>
        </div>
        <div className="row  p-3">
          <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">Code</th>
                <th scope="col">Country Name</th>
                <th scope="col">Country Abbreviation</th>
                <th scope="col">Sort Key</th>
                <th scope="col">Edit</th>
                <th scope="col">Delete</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th scope="row">1</th>
                <td>Mark</td>
                <td>Pakistan</td>
                <td>Pak</td>
                <td>
                  <button className="editBtnTable">Edit</button>
                </td>
                <td>
                  <button className="deleteBtnTable">Delete</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <div className="row mt-1 p-3">
          <div className="col-md-12 col-sm-12 p-2">
            <div className="    ">
              <button type="submit" className="btn btn-dark">
                Add New
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CountriesList;
