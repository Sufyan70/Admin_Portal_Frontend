import React from "react";
import "../assets/css/EducationLevelList.css";

function EducationLevelList() {
  return (
    <div className="container-fluid p-2">
      <div className="container-fluid mt-2  EducationLevelListContainer">
        <span className="EducationLevelListHeader py-2">Education Level List</span>
        <div className="row  p-3">
          <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">Code</th>
                <th scope="col">Education Level Name</th>
                <th scope="col">Edit</th>
                <th scope="col">Delete</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th scope="row">1</th>
                <td>Mark</td>
                <td>
                  <button className="editBtnTable">Edit</button>
                </td>
                <td>
                  <button className="deleteBtnTable">Delete</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <div className="row mt-1 p-3">
          <div className="col-md-12 col-sm-12 p-2">
            <div className="    ">
              <button type="submit" className="btn btn-dark">
                Add New
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default EducationLevelList;
