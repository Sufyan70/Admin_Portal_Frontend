import React from 'react'
import Header from '../../components/Includes/Header'
import './assets/css/HREmpListForm.css'
import { Link } from 'react-router-dom'

const EmpListForm = () => {
  return (
      <>
       <div>
        <Header />
       </div>
          <div className="container p-3">

          </div>
          <div className="container p3 mt-5">
              <div className="container-fluid mt-2 EmployeeListContainer ">
                  <span className="EmployeeListHeader py-2">
                      Employee Type Form
                  </span>
                  <div className="row mt-2 p-3">
                      <form>
                          <div className="form-row d-flex justify-content-between">                           
                              <div className="form-group col-md-4 mx-1">
                                  <label  className='text-dark'>Employee Type</label>
                                  <input type="" className="form-control" />
                              </div>
                              <div className="form-group col-md-4">
                                  <label  className='text-dark'>Employee Type Abbrivation</label>
                                  <input type="" className="form-control" />
                              </div>
                              <div className="form-group col-md-4">
                                  <label className='text-dark'>PermanantFlag</label>
                                  <div className="form-control d-flex align-item-center">
                                      <input type="Checkbox" className="form-check-input" />
                                      <label className='text-dark'>Flag</label>
                                  </div>
                              </div>
                          </div>
                          <div className="form-row mt-2 d-flex justify-content-between">
                              <div className="form-group col-md-4 mx-1">
                                  <label  className='text-dark'>Company Code</label>
                                  <input type="Number" className="form-control" />
                              </div>
                              <div className="form-group col-md-4">
                                  <label  className='text-dark'>Retirement Age</label>
                                  <input type="Number" className="form-control" />
                              </div>
                              <div className="form-group col-md-4">
                                  <label for="inputEmail4" className='text-dark'>Company Employee Flag </label>
                                  <div className="form-control d-flex align-item-center">
                                      <input type="Checkbox" className="form-check-input" />
                                      <label for="inputEmail4" className='text-dark'>Flag</label>
                                  </div>
                              </div>
                          </div>
                          <div className="form-row mt-2 d-flex justify-content-between">
                              <div className="form-group col-md-4">
                                  <label for="inputEmail4" className='text-dark'>Probation Month</label>
                                  <input type="Date" className="form-control" />
                              </div>
                              <div className="form-group col-md-4 mx-1">
                                  <label className='text-dark'>Appraisal Date</label>
                                  <input type="Date" className="form-control" />
                              </div>
                              <div className="form-group col-md-4 mx-1">
                                  <label  className='text-dark'>Change Probation Month</label>
                                  <input type="Date" className="form-control" />
                              </div>
                            
                          </div>
                          <div className="form-row mt-2 d-flex justify-content-between">
                              <div className="form-group col-md-4 mx-1">
                                  <label  className='text-dark'>Sort_key</label>
                                  <input type="text" className="form-control"/>
                              </div>
                          </div>
                          <button type="submit"  className="mt-3 btn btn-dark">Submit</button>
                      </form>
                  
                  </div>
              </div>
          </div>
      </>
  )
}

export default EmpListForm