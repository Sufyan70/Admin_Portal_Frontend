import React from 'react'
import Header from '../components/Includes/Header';
import MasterPersonal_list from './components/MasterPersonal';

const MasterPersonal = () => {
    return (
        <>
            <div>
                <Header />
            </div>
            <div className='mt-5'>
                <MasterPersonal_list />
            </div>
        </>
    )
}

export default MasterPersonal;