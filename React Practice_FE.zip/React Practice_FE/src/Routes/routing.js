import React from 'react'
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.css";
import '../../src/Assets/css/main.css'
import { Login } from '../LoginScreens/Login';
import  Dashboard   from '../dashboard/dashboard';
import TransactionAppointmentPage from '../TransactionAppointment/TransactionAppointmentPage';
import TAPersonalform from '../TransactionAppointForm/TAPersonalform';
import TAEducationForm from '../TransactionAppointForm/TAEducationForm';
import TAExprienceForm from '../TransactionAppointForm/TAExprienceForm';
import TASalaryForm from '../TransactionAppointForm/TASalaryForm';
import TAppointmentMasterPayroll from  '../TransactionAppointForm/TAppointmentMasterPayroll';
import TACheckList from '../TransactionAppointForm/TACheckList'
import TAFamilyForm from '../TransactionAppointForm/TAFamilyForm';
import TAShortsCut from '../TransactionAppointForm/TAShortsCut'
import Employee_Type from '../HrOperations/Employee_Type';
import DivisionList from '../HrOperations/DivisionList'
import DepartmentList from '../HrOperations/DepartmentList';
import EmpListForm from '../HrOperations/form/EmpListForm'
import SectionList from "../HrOperations/SectionList";
import CostCentersList from "../HrOperations/CostCentersList";
import EducationLevelList from "../HrOperations/EducationLevelList";
import EmployeeCategoryList from "../HrOperations/EmployeeCategoryList";
import CountriesList from "../HrOperations/CountriesList";
import GradeList from "../HrOperations/GradesList";
import EducationList from '../HrOperations/EducationList';
import Designations from '../HrOperations/Designations';
import LeaveCatList from '../HrOperations/LeaveCatList'
import LeaveType from '../HrOperations/LeaveType'
import PreEmployer from '../HrOperations/PreEmployer'
import Transportation from '../HrOperations/Transportation'
import Institutions from '../HrOperations/Institutions'
import Resignations from '../HrOperations/Resignations';
import Religion from '../HrOperations/Religion';
import Locations from '../HrOperations/Locations';
import MasterData_Sec from '../Master_Maintaince/MasterData_Sec'
import MasterData_Leaves from '../Master_Maintaince/MasterData_Leaves';
import MasterPersonal from '../Master_Maintaince/MasterPersonal';
import TransactionConfirmation from '../ContractEmployeeLeaves/Transaction_Confirmations';
import Transaction_Confirmation_Form from '../ContractEmployeeLeaves/Forms/TransactionConfirmation_Form';
import Transaction_Increment from '../ContractEmployeeLeaves/Transaction_Increment'
import Transaction_Increment_Form from '../ContractEmployeeLeaves/Forms/TransactionIncrement_Form'
import Transaction_Leaves_Delition_Form from '../ContractEmployeeLeaves/Forms/TransactionLeavesDelition';

const routing = () => {
  return (
    <>
      <Router>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/TransactionAppointmentPage" element={<TransactionAppointmentPage />}/>
          <Route path="/TAPersonalform" element={<TAPersonalform />} />
          <Route path="/TAEducationForm" element={<TAEducationForm />} />
          <Route path="/TAExprienceForm" element={<TAExprienceForm />} />
          <Route path="/TASalaryForm" element={<TASalaryForm />} />
          <Route path="/TAppointmentMasterPayroll" element={<TAppointmentMasterPayroll />} />
          <Route path="/TACheckList" element={<TACheckList />} />
          <Route path="/TAFamilyForm" element={<TAFamilyForm />} />
          <Route path="/TAShortsCut" element={<TAShortsCut />} />
          <Route path="/Employee_Type" element={<Employee_Type />} />
          <Route path="/DivisionList" element={<DivisionList />} />
          <Route path="/DepartmentList" element={<DepartmentList />} />
          <Route path="/EmpListForm" element={<EmpListForm />} />
          <Route path="/SectionList" element={<SectionList />} />
          <Route path="/CostCentersList" element={<CostCentersList />} />
          <Route path="/EducationLevelList" element={<EducationLevelList />} />
          <Route path="/EmployeeCategoryList" element={<EmployeeCategoryList />} />
          <Route path="/CountriesList" element={<CountriesList />} />
          <Route path="/GradeList" element={<GradeList />} />
          <Route path="/EducationList" element={<EducationList />} />
          <Route path="/Designations" element={<Designations />} />
          <Route path="/LeaveCatList" element={<LeaveCatList />} />
          <Route path="/LeaveType" element={<LeaveType />} />
          <Route path="/PreEmployer" element={<PreEmployer />} />
          <Route path="/Transportation" element={<Transportation />} />
          <Route path="/Institutions" element={<Institutions />} />
          <Route path="/Resignations" element={<Resignations />} />
          <Route path="/Religion" element={<Religion />} />
          <Route path="/Locations" element={<Locations />} />
          <Route path="/MasterData_Sec" element={<MasterData_Sec />} />
          <Route path="/MasterData_Leaves" element={<MasterData_Leaves />} />
          <Route path="/MasterPersonal" element={<MasterPersonal />} />
          <Route path="/TransactionConfirmation" element={<TransactionConfirmation />} />
          <Route path="/Transaction_Confirmation_Form" element={<Transaction_Confirmation_Form />} />
          <Route path="/Transaction_Increment" element={<Transaction_Increment />} />
          <Route path="/Transaction_Increment_Form" element={<Transaction_Increment_Form />} />
          <Route path="/Transaction_Leaves_Delition_Form" element={<Transaction_Leaves_Delition_Form />} />


        </Routes>
      </Router>
    </>
  );
}

export default routing