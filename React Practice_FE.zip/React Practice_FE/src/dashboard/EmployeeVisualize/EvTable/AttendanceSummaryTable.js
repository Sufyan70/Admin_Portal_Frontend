import React from 'react'

function AttendanceSummaryTable() {
  return (
    <div>AttendanceSummaryTable</div>
  )
}

export default AttendanceSummaryTable