import React from 'react'

function NewTable() {
  return (
    <div>NewTable</div>
  )
}

export default NewTable