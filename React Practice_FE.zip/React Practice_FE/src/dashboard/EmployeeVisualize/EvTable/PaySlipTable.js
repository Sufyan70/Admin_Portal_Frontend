import React from 'react'

function PaySlipTable() {
  return (
    <div>PaySlipTable</div>
  )
}

export default PaySlipTable