import React from 'react'

function TeamWorkTable() {
  return (
    <div>TeamWorkTable</div>
  )
}

export default TeamWorkTable